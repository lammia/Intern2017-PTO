CREATE TABLE TEAM(
	TeamId char(4) NOT NULL PRIMARY KEY,
    TeamName char(30)
);
CREATE TABLE ENGINEER(
	EnId char(5) NOT  NULL PRIMARY KEY,
    TeamId char(4) NOT NULL,
    Email varchar(50) NOT NULL,
    Password varchar(100) NOT NULL,
    FullName varchar(100) NOT NULL,
    DayLeft int NOT NULL,
    CONSTRAINT FK_TeamId FOREIGN KEY (TeamId) REFERENCES TEAM(TeamId)
    ON UPDATE CASCADE
    ON DELETE CASCADE
);
CREATE TABLE TEAM_MANAGER(
	MgId char(5) NOT NULL PRIMARY KEY,
	TeamId char(4) NOT NULL,
	Email varchar(50) NOT NULL,
    Password varchar(100) NOT NULL,
    FullName varchar(100) NOT NULL,
    DayLeft int,
    CONSTRAINT FK_TeamId2 FOREIGN KEY (TeamId) REFERENCES TEAM(TeamId)
    ON UPDATE CASCADE
    ON DELETE CASCADE
);
CREATE TABLE ADMINISTRATOR(
	AdId char(40) NOT NULL PRIMARY KEY,
    Email varchar(50) NOT NULL,
    Password varchar(100) NOT NULL,
    FullName varchar(100) NOT NULL
);
CREATE TABLE PTO_REQUEST(
	RqId char(6) NOT NULL PRIMARY KEY,
	EnId char(5),
	MgId char(5),
	DateOfRequest date NOT NULL,
	DateStart date NOT NULL,
	DateEnd date NOT NULL,
	Reason varchar(500),
	ApprovalOfManager int NOT NULL,
	ReasonForRejected varchar(500),
	ApprovalOfAdmin int NOT NULL,
	CHECK (DateOfRequest <= DateStart and DateStart < DateEnd),
	CONSTRAINT FK_UserId FOREIGN KEY (EnId) REFERENCES ENGINEER(EnId)
	ON UPDATE CASCADE,
	CONSTRAINT FK_UserId2 FOREIGN KEY (MgId) REFERENCES TEAM_MANAGER(MgId)
	ON UPDATE CASCADE
)